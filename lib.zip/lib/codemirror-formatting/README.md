# Codemirror formatting addon

The original one from http://codemirror.net/2/demo/formatting.html but with module loader
